# Source

- A. Szabo and N. S. Ostlund, "Modern Quantum Chemistry: Introduction to Advanced
  Electronic Structure Theory" (Macmillan 1982; Dover reprint 1996). Chapter 3
  (Roothaan equations, the minimal-basis H2 and HeH+ examples, Section 3.5), Appendix A
  (integrals over s-type Gaussians and the F0 function) and Appendix B (the HeH+ SCF
  program and its output).
- W. J. Hehre, R. F. Stewart and J. A. Pople, "Self-consistent molecular-orbital
  methods. I. Use of Gaussian expansions of Slater-type atomic orbitals", J. Chem.
  Phys. 51, 2657 (1969). The STO-3G expansion.
- S. F. Boys, "Electronic wave functions. I. A general method of calculation for the
  stationary states of any molecular system", Proc. R. Soc. London A 200, 542 (1950).
  Gaussian basis functions and the F0 function.
- CODATA 2018 recommended values for the hartree, the bohr radius, the atomic mass
  constant and the speed of light (given explicitly in the step 5 prompt).

Checks against the literature: for H2 (zeta = 1.24, R = 1.4 bohr) the reference code
gives S01 = 0.6593, H00 = -1.1204, H01 = -0.9584, (00|00) = 0.7746, (00|11) = 0.5697,
(01|01) = 0.2970, (00|01) = 0.4441 and E = -1.1167 hartree, matching the numbers printed
in Szabo and Ostlund, Section 3.5.2. For HeH+ it gives S01 = 0.4508, H00 = -2.6527,
H01 = -1.3472, H11 = -1.7318, matching their Appendix B output.

The combination of steps, the treatment of the dissociation limit and the parameter ranges are our own design.

Checks for steps 4 and 5: the reference full CI (configuration state functions in the RHF orbitals) agrees to about 1e-14 hartree with the lowest eigenvalue of the 4 x 4 non-orthogonal product-basis Hamiltonian and with the second solution (Loewdin orbitals). The analytic limit reproduces He = -2.643876 and H = -0.466582 hartree in this basis, and E_fci(R) - E_inf times R tends to the fragment-charge product (for example -1 for the ion pair). The sinc-DVR levels are converged to 2e-5 cm^-1 (grid step 0.02 vs 0.013 bohr, domain [0.35, 16] vs [0.22, 24]) over random valid parameters, and agree with Numerov shooting and with Chebyshev collocation to better than 1e-3 cm^-1.
The second solution is independent of the reference: shell-theorem radial quadrature
instead of closed-form Gaussian integrals, direct orbital minimization instead of the
self-consistent field, full CI in Loewdin orbitals, and for the levels a Chebyshev
interpolant of V in ln R with Chebyshev spectral collocation instead of the sinc DVR.

## How the test targets are obtained

No target is copied from the reference solution. Every test computes its own target:

| Target | Method in the test | Note / limit of validity |
|---|---|---|
| F0(t) (step 1) | 400-point Gauss-Legendre quadrature of the defining integral (cut at u = 10 / sqrt(t) when t > 100); exact limits F0(0) = 1, 1 - t/3 for tiny t, (1/2) sqrt(pi / t) for t = 1e4 | about 1e-13 relative; test tolerance 1e-11 relative (the stated requirement) |
| S, H (step 2) | shell theorem: every integral becomes a 1-D radial integral of one Gaussian averaged over spheres around the other centre, done with composite 16-point Gauss-Legendre; the nuclear attraction is the potential of a Gaussian charge cloud, also by 1-D quadrature (no F0, no erf) | about 1e-15; test tolerance 1e-10 absolute |
| (ij\|kl) (step 3) | same reduction: the potential of one Gaussian cloud averaged over spheres around the centre of the other cloud, then integrated over the radius | about 1e-15; test tolerance 1e-10 absolute |
| RHF energy (step 4) | direct minimization of 2 h + J over the single orbital-mixing angle with the test-side quadrature integrals (no Fock matrix, no iteration) | about 1e-15; test tolerance 1e-9 absolute |
| full-CI energy (step 4) | lowest eigenvalue of the two-electron Hamiltonian in the non-orthogonal product basis phi_i(1) phi_j(2) (generalized eigenproblem, overlap S (x) S) with the quadrature integrals | about 1e-15; test tolerance 1e-9 absolute |
| dissociation limit (step 5, general) | one-centre norm, core energy and (aa\|aa) by adaptive radial quadrature (scipy quad, the Coulomb term through the radial potential of the charge cloud); lowest of the three fragment arrangements; fragment-charge product checked for the ion-pair (-1) and fractional-charge (+0.25) cases | about 1e-12 hartree |
| vibrational levels (step 5, general) | full-CI curve from test-side closed-form integrals vectorized over R and the product-basis eigenproblem; renormalized Numerov shooting with node counting and bisection on steps 0.004 and 0.008 bohr over [0.25, 22], Richardson-extrapolated | below 1e-3 cm^-1; test tolerance 0.01 cm^-1 |
| sanity bands | Szabo and Ostlund values: S01, H00, H01, (00\|00), (00\|11), (01\|01), (00\|01) for H2; S01, H00, H01, H11 for HeH+; E_rhf = -1.1167 (H2) and -2.8607 (HeH+), E_fci = -1.1373 (H2); stretched H2 full CI near 2 x -0.466582 | bands of 1e-4 to 2e-3 only |

## Version 2 changes

Step 1: the stated and tested relative accuracy of F0 are the same, 1e-11 (quadrature target accurate
to ~1e-13); a 0-d result may be a 0-d array or a numpy float. Step 2: ZB = 0, zetaB = 0 and zetaB < 0
are tested as ValueError. Step 5: the bond length must lie within 1e-6 bohr of the minimum of the
test-side curve (slope / curvature), as stated; the isotope comparison allows twice that, since each
result carries its own 1e-6 error.

## Version 4 changes

Step 4 returns the full-CI and RHF energies. Step 5 computes the five lowest vibrational
levels from the exact R -> infinity limit, obtained from one-centre integrals and the
lowest fragment arrangement, instead of the energy at 60 bohr (which is wrong by
q_A q_B / 60 hartree for charged fragments). Step 5 is tested on an ion-pair limit
(-1/R tail) and a fractional-charge limit (+0.25/R tail) besides H2, D2 and HeH+; its
validation checks were cut to two (no five bound levels for He2 2+, a zero mass), with
no separate type or shape assertions.
